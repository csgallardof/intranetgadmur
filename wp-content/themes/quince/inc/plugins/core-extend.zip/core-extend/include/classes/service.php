<?php

class WPBakeryShortCode_VC_Service extends WPBakeryShortCode {
    public function outputTitle($title) {
        return '';
    }
}