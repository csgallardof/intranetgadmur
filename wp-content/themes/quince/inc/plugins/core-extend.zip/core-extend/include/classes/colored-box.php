<?php
class WPBakeryShortCode_VC_Colored_Box extends WPBakeryShortCode {

}