<?php

class WPBakeryShortCode_VC_Team extends WPBakeryShortCode {
    public function outputTitle($title) {
        return '';
    }
}